# AIO-Video-Downloader
The AIO App was originally created for online video saving purpose. It was first available on google play but had been removed after 8 months from its first release. So I have turn the project to an open sourced project.

[![Download AIO Video Download Manager](https://a.fsdn.com/con/app/sf-download-button)](https://sourceforge.net/projects/aio-video-download-manager/files/latest/download)

[![Download AIO Video Download Manager](https://img.shields.io/sourceforge/dm/aio-video-download-manager.svg)](https://sourceforge.net/projects/aio-video-download-manager/files/latest/download)

# Why user will love this app ?
The app was a commercial app and now its free ( ad free ). And it have all the standard features that any video downloader can offers but also has the capability of saving youtube videos too. 

AIO is not limited to just a few supporting websites but has the capability to save all the flash video without any problem.

# Main Features
1 Web Browser
* Automatically capture video files form web pages.
* Tap on a video to download the video file.
* Integrated Google search.
* Ability to change browser's User-Agent.

2 Download Manager
* Super fast Downloading.
* Support multiple downloading at a same time.
* Live download progress bar and speed indicator.
* Support background download.
* Support pause, resume and cancel on download tasks.
* Show download progress Indicator notification.

3 Other Features
* Its a free app.
* Easy to use UI.
* Support music and other file download.
* Ability to get open from other apps.
* Other apps can call AIO to download video files(e.g. Email app can call AIO to download any file attachments).

# AIO Project Page
http://shiba58.github.io/aio-video-downloader/
