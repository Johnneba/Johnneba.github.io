package dialogs;

import android.app.Dialog;
import android.widget.EditText;
import android.widget.TextView;

public interface OnClickFav {

    public void onClick(Dialog d, TextView v, EditText t);


}
