package dialogs;

import android.app.Dialog;
import android.view.View;

public interface SiteChooserListener {

    public void onClick(Dialog d, View v, String s, String url);


}
