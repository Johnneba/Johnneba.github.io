package activity;

import android.app.Activity;

public class AdvertiseUtility {

    //Init the mobile core sdk to your activity.
    public static void init_mobilecore_sdk(Activity context) {
    }

    //Show full size ad while exiting the activity.
    public static void show_exit_ad(final Activity activity) {
    }

    public static void show_full_screen(Activity activity) {
    }

    //Show the stickeez ad.
    public static void show_stickeez(Activity activity) {
    }

    public static void setAdUnitsEventListener(final Activity activity) {
    }
}
