package youtube;


public class FileId extends YouTubeId {
    public FileId(String pId) {
        super(pId);
    }
}
