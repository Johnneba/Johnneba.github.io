/**
 *
 */
package youtube;


public class PlaylistId extends YouTubeId {
    public PlaylistId(String pId) {
        super(pId);
    }
}