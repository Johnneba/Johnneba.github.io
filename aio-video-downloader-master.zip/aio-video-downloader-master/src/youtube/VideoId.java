/**
 *
 */
package youtube;


public class VideoId extends YouTubeId {
    public VideoId(String pId) {
        super(pId);
    }
}