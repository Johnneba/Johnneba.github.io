package account;

/**
 * Account class holds all the information of the current user details.
 * Created by shibaprasad on 3/30/2015.
 */
public class Account {
    public String deviceID;
    public String name;
    public String emailID;
    public String deviceName;
    public String userName;
}
